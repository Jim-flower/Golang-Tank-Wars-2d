package enetank

type Entank struct {
	X float64
	Y float64
	D int
}
