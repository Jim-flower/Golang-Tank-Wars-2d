package bullet

type Bullet_ struct {
	X float64
	Y float64
}
