package main

import (
	"fmt"
	"image/color"
	"log"
	"math"
	"math/rand"
	"strconv"
	"sync"
	"time"

	ebiten "github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/ebitenutil"
	"github.com/hajimehoshi/ebiten/v2/inpututil"
	"go_tank.mod/bullet"
	"go_tank.mod/enetank"
)

const (
	screenWidth  = 300
	screenHeight = 300
	offset       = 1
	ballRadius   = 15
)

type we struct {
	x      float64
	y      float64
	scalex float64
	scaley float64
}
type booms struct {
	X float64
	Y float64
	F int
}

type Game struct {
	count       int
	keys        []ebiten.Key
	text        string
	bullets_all map[bullet.Bullet_]int

	bullets_enemy map[bullet.Bullet_]int
	enemytanks    []enetank.Entank
	altanks       []enetank.Entank
	//爆炸的坐标 记录下来
	boomcords map[bullet.Bullet_]int
	screen    *ebiten.Image

	dc int
}

func (g *Game) Layout(outsideWidth, outsideHeight int) (int, int) {
	return screenWidth, screenHeight
}

var (
	ballPositionX = float64(screenWidth) / 2
	ballPositionY = float64(screenHeight) / 2
	ballMovementX = float64(2)
	ballMovementY = float64(3)

	direction = 3
	lck       sync.Mutex
	Rlck      sync.RWMutex
)

var Wallcords [20]we

// 超级模式 也就是无敌罩子
var SuperModel = false

var imgPtank [4]*ebiten.Image

var imgWtank [4]*ebiten.Image

// 存放爆炸图片
var boomImages [8]*ebiten.Image

// 存放墙图
var wallsImage *ebiten.Image

// 存放 门户 图
var portal *ebiten.Image
var px, py float64

// 初始化 这个函数在main函数之前

func IsinWallSpace(x float64, y float64) bool {
	//这里墙空间是init之后就不变化 只有读的情况 考虑上读锁

	for _, v := range Wallcords {
		wx := v.x
		wy := v.y
		scalex := v.scalex
		scaley := v.scaley
		if (x > wx && x < wx+60*scalex) && (y > wy && y < wy+60*scaley) {

			return true
		}

	}
	return false
}

func IsinPortal(x float64, y float64) bool {
	//这里墙空间是init之后就不变化 只有读的情况 考虑上读锁

	wx := px
	wy := py
	scalex := 0.15
	scaley := 0.15
	if (x > wx && x < wx+124*scalex) && (y > wy && y < wy+200*scaley) {

		return true
	}
	return false
}

func init() {
	rand.Seed(33)
	var err error
	//墙初始化
	// Wallcords[0] = we{0, 0, 0.2, 0.2}
	// Wallcords[1] = we{0, 0, 0.2, 0.2}
	// 墙给它来个随机初始化 不去优化 墙重叠的情况了 ！！ 现在写几个函数来判断一个点是否在墙空间内 ！！！
	for k, _ := range Wallcords {
		x := float64(rand.Intn(300))
		y := float64(rand.Intn(300))
		scalex := 0.2 * float64(rand.Intn(6))
		scaley := 0.2 * float64(rand.Intn(6))
		Wallcords[k] = we{x, y, scalex, scaley}
	}

	walls, _, err := ebitenutil.NewImageFromFile("./img/walls.png")
	wallsImage = walls
	// portal.png

	if err != nil {
		log.Fatal(err)
	}
	//门户初始化
	portaltmp, _, err := ebitenutil.NewImageFromFile("./img/portal.png")
	portal = portaltmp
	if err != nil {
		log.Fatal(err)
	}
	imgP0, _, err := ebitenutil.NewImageFromFile("./img/up.png")

	if err != nil {
		log.Fatal(err)
	}
	imgP1, _, err := ebitenutil.NewImageFromFile("./img/right.png")
	if err != nil {
		log.Fatal(err)
	}
	imgP2, _, err := ebitenutil.NewImageFromFile("./img/down.png")
	if err != nil {
		log.Fatal(err)
	}
	imgP3, _, err := ebitenutil.NewImageFromFile("./img/left.png")
	if err != nil {
		log.Fatal(err)
	}
	imgPtank[0] = imgP0
	imgPtank[1] = imgP1
	imgPtank[2] = imgP2
	imgPtank[3] = imgP3
	imgW0, _, err := ebitenutil.NewImageFromFile("./img/p2tankU.png")

	if err != nil {
		log.Fatal(err)
	}
	imgW1, _, err := ebitenutil.NewImageFromFile("./img/p2tankR.png")
	if err != nil {
		log.Fatal(err)
	}
	imgW2, _, err := ebitenutil.NewImageFromFile("./img/p2tankD.png")
	if err != nil {
		log.Fatal(err)
	}
	imgW3, _, err := ebitenutil.NewImageFromFile("./img/p2tankL.png")
	if err != nil {
		log.Fatal(err)
	}
	imgWtank[0] = imgW0
	imgWtank[1] = imgW1
	imgWtank[2] = imgW2
	imgWtank[3] = imgW3

	//炸弹图片数组 初始化
	boomsinit()
}
func boomsinit() {
	//加载炸弹特效图片 一共八张
	// fmt.Println(len(boomImages))
	for k := range boomImages {

		img, _, err := ebitenutil.NewImageFromFile("./img/blast" + strconv.Itoa(k+1) + ".png")
		fmt.Println("加载 blast" + strconv.Itoa(k) + ".png")
		if err != nil {
			log.Fatal(err)
		}
		// fmt.Println(img)
		boomImages[k] = img

	}

}
func repeatingKeyPressed(key ebiten.Key) bool {
	const (
		delay    = 30
		interval = 3
	)
	d := inpututil.KeyPressDuration(key)
	if d == 1 {
		return true
	}
	if d >= delay && (d-delay)%interval == 0 {
		return true
	}
	return false
}
func (g *Game) Update() error {
	// fmt.Println(g.boomcords)

	g.count += 1

	//敌方坦克发射子弹
	lck.Lock()
	//
	if g.count%50 == 0 {
		for _, et := range g.enemytanks {
			// g.drawTankv1(screen, et.X, et.Y, et.D, color.RGBA{0, 255, 255, 255})
			// () et.X, et.Y, et.D, false)
			shoot := true //这个决定是否发射出子弹
			if shoot && rand.Intn(10) < 8 {
				g.bullets_enemy[bullet.Bullet_{et.X, et.Y}] = et.D
			}

		}
	}
	lck.Unlock()

	// movEtank(g)

	//动态移动ballPosition
	// ballPositionX += ballMovementX
	// ballPositionY += ballMovementY

	// if ballPositionX >= screenWidth-ballRadius || ballPositionX <= ballRadius {
	// 	ballMovementX *= -1
	// }

	// if ballPositionY >= screenHeight-ballRadius || ballPositionY <= ballRadius {
	// 	ballMovementY *= -1
	// }
	g.keys = inpututil.AppendPressedKeys(g.keys[:0])

	// var current_key ebiten.Key

	// 1.先确定按下去的是什么建
	if inpututil.IsKeyJustPressed(ebiten.KeySpace) {
		// fmt.Println("按了空格 但是无法确定按下的时间")
		lck.Lock()
		new_c := bullet.Bullet_{ballPositionX, ballPositionY}
		// new_c := map[float64]
		g.bullets_all[new_c] = direction
		lck.Unlock()

	} else if inpututil.IsKeyJustPressed(ebiten.KeyArrowUp) {
		// fmt.Println("按了上键 但是无法确定按下的时间")
	} else if inpututil.IsKeyJustPressed(ebiten.KeyArrowDown) {
		// fmt.Println("按了下键 但是无法确定按下的时间")
	} else if inpututil.IsKeyJustPressed(ebiten.KeyArrowLeft) {
		// fmt.Println("按了左键 但是无法确定按下的时间")
	} else if inpututil.IsKeyJustPressed(ebiten.KeyArrowRight) {
		// fmt.Println("按了又键 但是无法确定按下的时间")
	}
	// 直接根据按下持续的时间来控制速度
	duration_space := inpututil.KeyPressDuration(ebiten.KeySpace)
	if (duration_space%10 == 0) && (duration_space != 0) {
		lck.Lock()
		new_c := bullet.Bullet_{ballPositionX, ballPositionY}
		// new_c := map[float64]
		g.bullets_all[new_c] = direction
		lck.Unlock()
	}

	//这里我们使用内置函数来判断当前按下的按键
	const our_tank_offset = 2
	if len(g.keys) != 0 {
		// fmt.Printf("%T", g.keys[0])
		lck.Lock()
		switch g.keys[0] {
		case ebiten.KeyArrowLeft:
			tmpx := ballPositionX - float64(our_tank_offset)

			if !IsinWallSpace(tmpx, ballPositionY) {
				ballPositionX -= float64(our_tank_offset)
			}
			//在墙内
			if IsinPortal(tmpx, ballPositionY) {
				fmt.Println("在门内")
				for {
					a := float64(rand.Intn(300))
					b := float64(rand.Intn(300))
					if !IsinWallSpace(a, b) {
						ballPositionX = a
						ballPositionY = b
						break
					}

				}

			}
			direction = 3
		case ebiten.KeyArrowRight:
			tmpx := ballPositionX + float64(our_tank_offset)

			if !IsinWallSpace(tmpx, ballPositionY) {
				ballPositionX += float64(our_tank_offset)
			}
			if IsinPortal(tmpx, ballPositionY) {
				fmt.Println("在门内")
				for {
					a := float64(rand.Intn(300))
					b := float64(rand.Intn(300))
					if !IsinWallSpace(a, b) {
						ballPositionX = a
						ballPositionY = b
						break
					}

				}

			}

			direction = 1
		case ebiten.KeyArrowUp:

			tmpy := ballPositionY - float64(our_tank_offset)

			if !IsinWallSpace(ballPositionX, tmpy) {
				ballPositionY -= float64(our_tank_offset)
			}
			if IsinPortal(ballPositionX, tmpy) {

				for {
					a := float64(rand.Intn(300))
					b := float64(rand.Intn(300))
					if !IsinWallSpace(a, b) {
						ballPositionX = a
						ballPositionY = b
						break
					}

				}

			}
			direction = 0
		case ebiten.KeyArrowDown:
			tmpy := ballPositionY + float64(our_tank_offset)

			if !IsinWallSpace(ballPositionX, tmpy) {
				ballPositionY += float64(our_tank_offset)
			}
			if IsinPortal(ballPositionX, tmpy) {
				for {
					a := float64(rand.Intn(300))
					b := float64(rand.Intn(300))
					if !IsinWallSpace(a, b) {
						ballPositionX = a
						ballPositionY = b
						break
					}

				}

			}

			// ballPositionY += float64(our_tank_offset)
			direction = 2
			// case ebiten.KeySpace:
			// 	// fmt.Print("Space")
			// 	lck.Lock()
			// 	new_c := bullet.Bullet_{ballPositionX, ballPositionY}
			// 	// new_c := map[float64]
			// 	g.bullets_all[new_c] = direction
			// 	lck.Unlock()
			// fmt.Println(g.bullets_all)

			// switch direction {
			// case 0:

			// }

		}
		lck.Unlock()

	}

	//处理一下爆炸特效 除数为5 是时间间隔 敌方坦克发射子弹的间隔
	if g.count%5 == 0 {
		lck.Lock()
		boomcords := make(map[bullet.Bullet_]int)

		for kb, v := range g.boomcords {
			// 爆炸的坐标
			// bx := kb.X
			// by := kb.Y
			//只对小于7的炸弹进行增加
			if v < 7 {
				g.boomcords[kb] += 1
				boomcords[kb] = v + 1

			}

		}
		g.boomcords = boomcords
		lck.Unlock()
	}

	return nil
}

func (g *Game) drawCircle(screen *ebiten.Image, x, y, radius int, clr color.Color) {
	radius64 := float64(radius)
	minAngle := math.Acos(1 - 1/radius64)

	for angle := float64(0); angle <= 360; angle += minAngle {
		xDelta := radius64 * math.Cos(angle)
		yDelta := radius64 * math.Sin(angle)

		x1 := int(math.Round(float64(x) + xDelta))
		y1 := int(math.Round(float64(y) + yDelta))

		screen.Set(x1, y1, clr)
	}
}

// 画矩形
func (g *Game) drawRec(screen *ebiten.Image, x float64, y float64, gap_x float64, gap_y float64, clr color.Color) {

	for i := x; i < gap_x+x+1; i++ {
		for j := y; j < gap_y+y; j++ {
			screen.Set(int(i), int(j), clr)
		}
	}

}

// 画炸弹
func (g *Game) drawBoomv1(screen *ebiten.Image) error {

	op := &ebiten.DrawImageOptions{}
	// 设置初始位置 调整两次 一次是根据图片大小调整偏移  一次是 设置位置 为中间
	//先缩放
	op.GeoM.Scale(0.15, 0.15)

	// op.GeoM.Translate(-float64(sc)/2, -float64(frameHeight)/2)
	for kb, v := range g.boomcords {

		x := kb.X
		y := kb.Y
		op.GeoM.Translate(x-0.2*60*0.5, y-0.2*60*0.5)
		if v <= 7 {
			screen.DrawImage(boomImages[v], op)
		}

	}

	// 每当update函数调用5次 或者说 每间隔 dt 秒 找到即将展示的下一帧图片
	// lck.Lock()

	// lck.Unlock()

	return nil
}

// 画坦克 v1
func (g *Game) drawTankv1(screen *ebiten.Image, x float64, y float64, direction int, clr color.Color) {

	if direction == 0 {
		g.drawRec(screen, x-5, y-5, 10, 10, clr)
		g.drawRec(screen, x-10, y-10, 5, 20, clr)
		g.drawRec(screen, x+5, y-10, 5, 20, clr)
		g.drawRec(screen, x-2, y-13, 4, 13, clr)
		g.drawRec(screen, x-4, y-16, 8, 3, clr)
	} else if direction == 2 {
		g.drawRec(screen, x-5, y-5, 10, 10, clr)
		g.drawRec(screen, x-10, y-10, 5, 20, clr)
		g.drawRec(screen, x+5, y-10, 5, 20, clr)

		g.drawRec(screen, x-2, y+5, 4, 8, clr)
		g.drawRec(screen, x-4, y+13, 8, 3, clr)

	} else if direction == 1 {
		g.drawRec(screen, x-5, y-5, 10, 10, clr)
		g.drawRec(screen, x-10, y-10, 20, 5, clr)
		g.drawRec(screen, x-10, y+5, 20, 5, clr)
		g.drawRec(screen, x+5, y-2, 8, 4, clr)
		g.drawRec(screen, x+13, y-4, 3, 8, clr)
	} else if direction == 3 {

		g.drawRec(screen, x-5, y-5, 10, 10, clr)
		g.drawRec(screen, x-10, y-10, 20, 5, clr)
		g.drawRec(screen, x-10, y+5, 20, 5, clr)

		g.drawRec(screen, x-13, y-2, 8, 4, clr)
		g.drawRec(screen, x-16, y-4, 3, 8, clr)
	}

}

// 画坦克  v2
func (g *Game) drawTankv2(screen *ebiten.Image, x float64, y float64, direction int, cato bool) error {
	//先放缩一下 0.25 倍
	op := &ebiten.DrawImageOptions{}
	scale := 0.25
	op.GeoM.Scale(scale, scale)
	//设置位置
	// op.GeoM.Translate(-scale*30, scale*30)
	//这里这个60乘以0.5和是图片尺寸的一半
	op.GeoM.Translate(x-scale*60*0.5, y-scale*60*0.5)
	//为了区分敌我的坦克 这里判断一下

	if cato {
		//我方 渲染成绿色
		screen.DrawImage(imgWtank[direction], op)
	} else {
		//敌方 渲染成黄色
		screen.DrawImage(imgPtank[direction], op)
	}
	return nil
}
func (g *Game) DrawWall(screen *ebiten.Image, x float64, y float64, scalex float64, scaley float64) {
	op := &ebiten.DrawImageOptions{}

	op.GeoM.Scale(scalex, scaley)
	//这里的x y是墙的左上角原点
	// op.GeoM.Translate(x-scale*60*0.5, y-scale*60*0.5)
	op.GeoM.Translate(x, y)

	screen.DrawImage(wallsImage, op)

}

// 画门户
func (g *Game) DrawPortal(screen *ebiten.Image, x float64, y float64, scalex float64, scaley float64) {
	op := &ebiten.DrawImageOptions{}

	op.GeoM.Scale(scalex, scaley)
	//这里的x y是墙的左上角原点
	// op.GeoM.Translate(x-scale*60*0.5, y-scale*60*0.5)
	op.GeoM.Translate(x, y)

	screen.DrawImage(portal, op)

}

func (g *Game) Draw(screen *ebiten.Image) {
	g.dc += 1

	g.screen = screen

	// purpleClr := color.RGBA{255, 0, 255, 255}

	x := math.Round(ballPositionX)
	y := math.Round(ballPositionY)

	// 画墙 是60*60 放缩移动
	// 这里最好来个静态数组 然后循环画墙
	// fmt.Println(Wallcords)
	for _, v := range Wallcords {

		g.DrawWall(screen, v.x, v.y, v.scalex, v.scaley)
	}
	//
	// 画门户
	if g.dc%1000 == 0 && g.dc != 0 {

		px = float64(rand.Intn(300))
		py = float64(rand.Intn(300))
	}

	g.DrawPortal(screen, px, py, 0.15, 0.15)
	//画我方坦克
	// g.drawTankv1(screen, x, y, direction, purpleClr)
	g.drawTankv2(screen, x, y, direction, true)
	// 如果是无敌模式 要额外加一个无敌的罩子

	if SuperModel {
		g.drawCircle(screen, int(x), int(y), 15, color.White)

	}
	// 画敌方坦克  先需要有一个敌方坦克的类  里面有坦克的坐标 方向
	for _, et := range g.enemytanks {
		// g.drawTankv1(screen, et.X, et.Y, et.D, color.RGBA{0, 255, 255, 255})
		g.drawTankv2(screen, et.X, et.Y, et.D, false)

		// fmt.Println(g.enemytanks)
	}
	//画子弹 我方
	for k, _ := range g.bullets_all {
		dx := k.X
		dy := k.Y
		g.drawRec(screen, dx, dy, 1, 1, color.RGBA{0, 255, 0, 255})
		// g.drawRec(screen, dx, dy, 1, 1, color.White)
	}
	//画子弹 敌方
	for k, _ := range g.bullets_enemy {
		dx := k.X
		dy := k.Y
		g.drawRec(screen, dx, dy, 1, 1, color.RGBA{255, 0, 0, 125})

	}
	//画爆炸特效
	g.drawBoomv1(screen)

	//ebitenutil.DebugPrint(screen, strings.Join(keyStrs, ", "))

}

func cal_(g *Game) {
	for {
		// fmt.Println("888")
		lck.Lock()
		nmp := make(map[bullet.Bullet_]int)

		for k, v := range g.bullets_all {

			switch v {
			case 0:
				//我方子弹到达墙就销毁
				if (k.Y-float64(offset) < 0) || (k.Y-float64(offset) > screenHeight) || IsinWallSpace(k.X, k.Y-float64(offset)) {
					break
				}
				new_c := bullet.Bullet_{k.X, k.Y - float64(offset)}
				// new_c := map[float64]
				nmp[new_c] = v

			case 1:

				if (k.X+float64(offset) < 0) || (k.X+float64(offset) > screenWidth) || IsinWallSpace(k.X+float64(offset), k.Y) {
					break
				}
				new_c := bullet.Bullet_{k.X + float64(offset), k.Y}
				// new_c := map[float64]
				nmp[new_c] = v

			case 2:
				if (k.Y+float64(offset) < 0) || (k.Y+float64(offset) > screenHeight) || IsinWallSpace(k.X, k.Y+float64(offset)) {
					break
				}
				new_c := bullet.Bullet_{k.X, k.Y + float64(offset)}
				// new_c := map[float64]
				nmp[new_c] = v

			case 3:
				if (k.X-float64(offset) < 0) || (k.X-float64(offset) > screenWidth) || IsinWallSpace(k.X-float64(offset), k.Y) {
					break
				}
				new_c := bullet.Bullet_{k.X - float64(offset), k.Y}
				// new_c := map[float64]
				nmp[new_c] = v
			}

		}
		g.bullets_all = nmp
		lck.Unlock()

		time.Sleep(20 * time.Millisecond)

	}
}

func cal_enemy(g *Game) {
	for {
		// fmt.Println("888")
		lck.Lock()
		nmp := make(map[bullet.Bullet_]int)

		for k, v := range g.bullets_enemy {

			switch v {
			case 0:

				if (k.Y-float64(offset) < 0) || (k.Y-float64(offset) > screenHeight) || IsinWallSpace(k.X, k.Y-float64(offset)) {
					break
				}
				new_c := bullet.Bullet_{k.X, k.Y - float64(offset)}
				// new_c := map[float64]
				nmp[new_c] = v

			case 1:

				if (k.X+float64(offset) < 0) || (k.X+float64(offset) > screenWidth) || IsinWallSpace(k.X+float64(offset), k.Y) {
					break
				}
				new_c := bullet.Bullet_{k.X + float64(offset), k.Y}
				// new_c := map[float64]
				nmp[new_c] = v

			case 2:
				if (k.Y+float64(offset) < 0) || (k.Y+float64(offset) > screenHeight) || IsinWallSpace(k.X, k.Y+float64(offset)) {
					break
				}
				new_c := bullet.Bullet_{k.X, k.Y + float64(offset)}
				// new_c := map[float64]
				nmp[new_c] = v

			case 3:
				if (k.X-float64(offset) < 0) || (k.X-float64(offset) > screenWidth) || IsinWallSpace(k.X-float64(offset), k.Y) {
					break
				}
				new_c := bullet.Bullet_{k.X - float64(offset), k.Y}
				// new_c := map[float64]
				nmp[new_c] = v
			}

		}
		g.bullets_enemy = nmp
		lck.Unlock()
		time.Sleep(5 * time.Millisecond)

	}
}

func boom(g *Game) {
	fmt.Println("123")
	for {
		// time.Sleep(time.Second)
		// fmt.Println(g.enemytanks)
		lck.Lock()
		for k, v := range g.enemytanks {
			if (v.Y != 0) && (v.X != 0) {

				//遍历所有子弹
				// fmt.Println(len(g.bullets_all))

				for kb, _ := range g.bullets_all {

					bx := kb.X
					by := kb.Y
					distance := math.Sqrt(math.Pow((bx-v.X), 2) + math.Pow((by-v.Y), 2))
					if distance < 10 {

						// 这个时候说明子弹打到了坦克
						// enemytanks是数组 我们在这里需要删除 这个坦克元素

						// g.enemytanks[k].X = 0
						// g.enemytanks[k].Y = 0
						fmt.Println("爆炸！！！")
						//播放
						// go g.drawBoomv1(g.screen, bx, by)
						//记录爆炸位置 初始化第一帧  for循环外层已经加上了锁 所以不需要再加锁

						g.boomcords[bullet.Bullet_{bx, by}] = 0

						g.enemytanks = DeleteSlice(g.enemytanks, g.enemytanks[k])

						break
					}
					break

					// fmt.Println(kb)
					// fmt.Println(vb)

				}
				// fmt.Println(g.bullets_all)
				// for kb, v := range g.bullets_all {
				// 	fmt.Println(kb)
				// 	fmt.Println(v)

			}
		}
		lck.Unlock()
		time.Sleep(200)
	}
}

// 如果敌方子弹打中我方
func boom1(g *Game) {
	// fmt.Println("123")
	var boomsate = false
	for {
		// time.Sleep(time.Second)
		// fmt.Println(g.enemytanks)
		lck.Lock()
		X := ballPositionX
		Y := ballPositionY

		if (Y != 0) && (X != 0) {

			//遍历所有子弹
			// fmt.Println(len(g.bullets_all))

			for kb, _ := range g.bullets_enemy {

				bx := kb.X
				by := kb.Y
				distance := math.Sqrt(math.Pow((bx-X), 2) + math.Pow((by-Y), 2))
				if distance < 10 {

					// 这个时候说明子弹打到了坦克
					// enemytanks是数组 我们在这里需要删除 这个坦克元素

					// g.enemytanks[k].X = 0
					// g.enemytanks[k].Y = 0
					fmt.Println("we爆炸！！！")
					//播放
					// go g.drawBoomv1(g.screen, bx, by)
					//记录爆炸位置 我方爆炸最好只记录一次 延迟一下
					//
					g.boomcords[bullet.Bullet_{X, Y}] = 0

					boomsate = true

					// g.enemytanks = DeleteSlice(g.enemytanks, g.enemytanks[k])

					break
				}
				break

				// fmt.Println(kb)
				// fmt.Println(vb)

			}

			// fmt.Println(g.bullets_all)
			// for kb, v := range g.bullets_all {
			// 	fmt.Println(kb)
			// 	fmt.Println(v)

		}

		lck.Unlock()

		//这里是说 如果发现是从爆炸跳出来了 那么 就要随机生成 重生地址 并且 开启无敌护罩5秒
		if boomsate {
			//先让坦克 ”消失“ 3秒钟之后 出现
			ballPositionX = -600
			ballPositionY = -600
			time.Sleep(3 * time.Second)
			//重生之后随机出现在一个地点 这个地点一定不能在墙内
			for {
				a := float64(rand.Intn(screenWidth))
				b := float64(rand.Intn(screenWidth))
				if !IsinWallSpace(a, b) {
					ballPositionX = a
					ballPositionY = b
					break
				}
			}

			// ballPositionX = float64(rand.Intn(screenWidth))
			// ballPositionY = float64(rand.Intn(screenHeight))
			//开启无敌模式
			SuperModel = true
			//然后就是无敌5秒 5秒过后 无敌模式解除
			time.Sleep(5 * time.Second)
			SuperModel = false

			boomsate = false

		}
		//延迟就是防止死锁

		time.Sleep(200)
	}
}
func movEtank(g *Game) {
	//这里设置敌方坦克滑动速度
	var count int
	const move_offset = float64(3)
	for {
		time.Sleep(time.Second / 2)
		count += 1

		if count == 20 {
			count = 0
		}
		// fmt.Println(len(g.enemytanks))
		// fmt.Println(g.enemytanks)

		lck.Lock()
		for k, v := range g.enemytanks {

			if (v.Y < 0) || (v.Y > screenHeight) || (v.X < 0) || (v.X > screenWidth) {
				// fmt.Println("不在范围内")
				g.enemytanks = DeleteSlice(g.enemytanks, g.enemytanks[k])
				break
			}

			switch v.D {
			case 0:
				tmpy := v.Y - move_offset
				if !IsinWallSpace(v.X, tmpy) {
					g.enemytanks[k].Y = v.Y - move_offset
				}
				// fmt.Println(count)
				if count%10 == 0 {
					g.enemytanks[k].D = rand.Intn(4)

				}

			case 1:
				tmpx := v.X + move_offset
				if !IsinWallSpace(tmpx, v.Y) {
					g.enemytanks[k].X = v.X + move_offset
				}
				if count%10 == 0 {
					g.enemytanks[k].D = rand.Intn(4)

				}

			case 2:
				tmpy := v.Y + move_offset
				if !IsinWallSpace(v.X, tmpy) {
					g.enemytanks[k].Y = v.Y + move_offset
				}
				if count == 10 {
					g.enemytanks[k].D = rand.Intn(4)

				}

			case 3:
				tmpx := v.X - move_offset
				if !IsinWallSpace(tmpx, v.Y) {
					g.enemytanks[k].X = v.X - move_offset
				}
				if count == 10 {
					g.enemytanks[k].D = rand.Intn(4)

				}

			}
		}
		//场上没有坦克的时候再造几个出来
		if len(g.enemytanks) <= 2 {
			for i := 0; i < rand.Intn(7); i++ {

				var tank = enetank.Entank{float64(rand.Intn(300)), float64(rand.Intn(300)), rand.Intn(3)}

				// 同理不能够在墙上
				if !IsinWallSpace(tank.X, tank.Y) {
					g.enemytanks = append(g.enemytanks, tank)
				}

			}
		}
		lck.Unlock()
		time.Sleep(200)

	}
}
func DeleteSlice(a []enetank.Entank, elem enetank.Entank) []enetank.Entank {
	j := 0
	for _, v := range a {
		if v != elem {
			a[j] = v
			j++
		}
	}
	if j == 0 {
		return make([]enetank.Entank, 0)

	}
	return a[:j]
}

func main() {
	// a := bullet.Bullet_{}

	fmt.Println("Hallo")
	ebiten.SetWindowSize(screenWidth*2, screenHeight*2)
	ebiten.SetWindowTitle("War of Tank")

	g := &Game{}
	g.enemytanks = make([]enetank.Entank, 0)

	for i := 0; i < 5; i++ {

		var tank = enetank.Entank{float64(rand.Intn(300)), float64(rand.Intn(300)), rand.Intn(3)}
		//初始化的时候千万不能够在墙空间上
		if !IsinWallSpace(tank.X, tank.Y) {
			g.enemytanks = append(g.enemytanks, tank)
		}

	}

	// fmt.Print(g.enemytanks)
	// 开启线程用于控制已经发出的子弹 这个线程是和all bullet绑定的  敌方的还没有

	//下面两个线程一定要计算好for循环的间隔 不然对于不同cpu可能执行速度不一样 ！！！ 最好以mill为单位
	go cal_(g)

	go cal_enemy(g)
	// 开启线程控制敌方坦克移动
	go movEtank(g)
	// 控制爆炸特效
	// go g.vanishBoom()

	g.bullets_all = make(map[bullet.Bullet_]int)
	g.bullets_enemy = make(map[bullet.Bullet_]int)

	g.boomcords = make(map[bullet.Bullet_]int)

	go boom(g)

	go boom1(g)
	// go monitor(g)

	// go boom_us(g)

	// go vanishBoom(g)

	if err := ebiten.RunGame(g); err != nil {
		panic(err)
	}

}
